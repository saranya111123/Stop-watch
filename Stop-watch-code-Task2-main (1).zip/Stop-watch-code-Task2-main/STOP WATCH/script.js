
let startTime, interval, elapsed = 0;
const display = document.getElementById('display');
const startBtn = document.getElementById('start');
const pauseBtn = document.getElementById('pause');
const resetBtn = document.getElementById('reset');
const lapBtn = document.getElementById('lap');
const lapsList = document.getElementById('laps');
const clearLapsBtn = document.getElementById('clearLaps');
const darkModeToggle = document.getElementById('darkModeToggle');

function formatTime(ms) {
  let milliseconds = ms % 1000;
  let totalSeconds = Math.floor(ms / 1000);
  let seconds = totalSeconds % 60;
  let minutes = Math.floor(totalSeconds / 60) % 60;
  let hours = Math.floor(totalSeconds / 3600);
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}.${pad(milliseconds, 3)}`;
}

function pad(num, size = 2) {
  return num.toString().padStart(size, '0');
}

function updateTime() {
  const now = Date.now();
  const timePassed = now - startTime + elapsed;
  display.textContent = formatTime(timePassed);
}

function saveLapToStorage(time) {
  const laps = JSON.parse(localStorage.getItem('laps') || '[]');
  laps.push(time);
  localStorage.setItem('laps', JSON.stringify(laps));
}

function loadLapsFromStorage() {
  const laps = JSON.parse(localStorage.getItem('laps') || '[]');
  lapsList.innerHTML = '';
  laps.forEach((time, index) => {
    const lapItem = document.createElement('li');
    lapItem.textContent = `Lap ${index + 1}: ${time}`;
    lapsList.appendChild(lapItem);
  });
}

function clearLapStorage() {
  localStorage.removeItem('laps');
}

startBtn.onclick = () => {
  startTime = Date.now();
  interval = setInterval(updateTime, 50);
  startBtn.disabled = true;
  pauseBtn.disabled = false;
};

pauseBtn.onclick = () => {
  clearInterval(interval);
  elapsed += Date.now() - startTime;
  startBtn.disabled = false;
  pauseBtn.disabled = true;
};

resetBtn.onclick = () => {
  clearInterval(interval);
  startTime = null;
  elapsed = 0;
  display.textContent = '00:00:00.000';
  startBtn.disabled = false;
  pauseBtn.disabled = false;
};

lapBtn.onclick = () => {
  if (interval) {
    const lapTime = Date.now() - startTime + elapsed;
    const formattedTime = formatTime(lapTime);
    const lapItem = document.createElement('li');
    lapItem.textContent = `Lap ${lapsList.children.length + 1}: ${formattedTime}`;
    lapsList.appendChild(lapItem);
    saveLapToStorage(formattedTime);
  }
};

clearLapsBtn.onclick = () => {
  lapsList.innerHTML = '';
  clearLapStorage();
};

darkModeToggle.onclick = () => {
  document.body.classList.toggle('dark-mode');
  darkModeToggle.textContent = document.body.classList.contains('dark-mode') ? '☀️ Light Mode' : '🌙 Dark Mode';
};

window.onload = loadLapsFromStorage;
